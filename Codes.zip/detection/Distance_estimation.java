package org.tensorflow.lite.examples.detection;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.*;

public class Distance_estimation {
    static HashMap<String, Integer> hmap = new HashMap<String, Integer>();
    static HashMap<String, Integer> hmap2 = new HashMap<String, Integer>();

    public static void create_hmap()throws IOException
    {
        hmap2.put("dog",40);
        hmap2.put("person",40);
        hmap2.put("bicycle",50);
        hmap2.put("truck",200);
        hmap2.put("chair",50);
        hmap2.put("sofa",70);
        hmap2.put("couch",70);
        hmap2.put("table",50);
        hmap2.put("bed",55);
        hmap2.put("oven",30);
        hmap2.put("suitcase",40);
        hmap2.put("laptop",22);

        hmap2.put("car",150);
        hmap2.put("motorcycle",70);
        hmap2.put("airplane",700);
        hmap2.put("bus",290);
        hmap2.put("train",250);
        hmap2.put("boat",200);
        hmap2.put("traffic light",40);
        hmap2.put("fire hydrant",38);
        hmap2.put("stop sign",25);
        hmap2.put("backpack",40);
        hmap2.put("umbrella",30);
        hmap2.put("handbag",20);
        hmap2.put("tennis racket",40);
        hmap2.put("bottle",18);
        hmap2.put("wine glass", 17);
        hmap2.put("cup",7);
        hmap2.put("fork",10);
        hmap2.put("knife",10);
        hmap2.put("spoon",10);
        hmap2.put("bowl",7);

        hmap2.put("apple",6);
        hmap2.put("banana",6);
        hmap2.put("orange",6);
        hmap2.put("pizza",2);
        hmap2.put("donut",2);
        hmap2.put("cake",6);
        hmap2.put("potted plant", 30);
        hmap2.put("dining table",50);
        hmap2.put("toilet",36);
        hmap2.put("tv",26);
        hmap2.put("keyboard",10);


        hmap2.put("cell phone",12);
        hmap2.put("microwave",40);
        hmap2.put("sink",30);
        hmap2.put("refridgerator",300);
        hmap2.put("book",20);
        hmap2.put("clock",29);
        hmap2.put("vase",30);
        hmap2.put("teddy bear",30);
        hmap2.put("toothbrush",10);
        hmap2.put("hair dryer",19);
    }


    public static int calculate_distance(float focal_length,float sensor_height,String obj_name ,int obj_pix_height,int obj_actual_height) {
        int pixel_FL;
        pixel_FL = (int)((480*focal_length)/sensor_height);
        int distance = ((pixel_FL )* obj_actual_height) / obj_pix_height;
        hmap.put(obj_name, distance);
        return distance;
    }

    public static String get_direction(String obj_name, int width_obj, int left_pix)
    {
        int val = 100;
        int p1=val;
        String direc="";
        int p2=200;
        int mid=((width_obj)/2)+left_pix;

        Log.d("mytag","width is : "+width_obj+" mid is : "+mid);
        if(mid>p1 && mid<p2)
            direc="Front";
        else if(mid<p1)
            direc="Left";
        else
            direc="Right";

        Log.d("mytag","Object: "+obj_name+" Direction : "+direc);
        return direc;
    }

}